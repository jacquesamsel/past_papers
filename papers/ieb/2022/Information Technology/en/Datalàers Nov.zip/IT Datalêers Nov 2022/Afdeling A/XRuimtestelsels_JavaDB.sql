CREATE TABLE tblKapteins (
KapteinID INTEGER NOT NULL PRIMARY KEY 
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1),
VolleNaam VARCHAR(60),
DatumAangestel DATE,
GevegOpleiding BOOLEAN
);

CREATE TABLE tblRuimteskepe (
RuimteskipID INTEGER NOT NULL PRIMARY KEY 
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1),
Model VARCHAR(60),
Spoed DOUBLE,
BrandstofVerbruik INTEGER,
BrandstofKapasiteit INTEGER
); 

CREATE TABLE tblSendings (
SendingID INTEGER NOT NULL PRIMARY KEY 
GENERATED ALWAYS AS IDENTITY 
(START WITH 1, INCREMENT BY 1),
KapteinID INTEGER,
RuimteskipID INTEGER,
Hoofdoelwit VARCHAR(60),
VertrekDatum DATE,
Afstand INTEGER,
Sonnestelsel VARCHAR(60)
); 


INSERT INTO tblKapteins (VolleNaam, DatumAangestel, GevegOpleiding) VALUES
('Neliswa Tlailane','2006-08-31',TRUE),
('Themba Morena','2007-03-28',TRUE),
('Mamello Mthandi','2009-03-15',FALSE),
('Lyle Foster','2010-08-20',TRUE),
('Bongeka Makhurubetshi','2006-10-20',TRUE),
('Oratile Tshabalala','2010-05-17',FALSE),
('Ben Motshwari','2009-02-12',TRUE),
('Innocent Maela','2007-09-16',FALSE),
('Thapelo Erasmus','2008-09-22',TRUE),
('Gabriela Salgado','2005-02-11',FALSE),
('Bongani Zungu','2010-08-22',FALSE),
('Pride Kgoale','2010-09-07',FALSE),
('Thulani Xulu','2006-11-04',FALSE),
('Siyanda Gamildien','2010-02-05',FALSE),
('Andile Makhabane','2008-05-23',FALSE),
('Andile Hlatshwayo','2005-09-28',TRUE),
('Kermit Phete','2011-03-04',TRUE),
('Sipho Hlanti','2010-12-24',TRUE),
('Nonhlanhla Ndlangisa','2009-08-12',FALSE),
('Ronwen Williams','2011-04-22',FALSE),
('Veli Mothwa','2007-08-31',FALSE),
('Koketso Gamede','2008-09-02',TRUE),
('Thulani Jali','2008-09-13',FALSE),
('Sifiso Mbule','2008-10-03',TRUE),
('Kaylin Nthite','2010-11-17',FALSE),
('Itumeleng Khune','2010-09-18',FALSE),
('Percy Serero','2008-07-31',TRUE),
('Dean Furman','2008-02-23',TRUE),
('Craig Tau','2006-09-24',FALSE),
('Nomvula Moodaly','2009-03-01',FALSE),
('Kaylyn Holweni','2008-03-31',FALSE),
('Robyn Luthuli','2010-04-29',FALSE),
('Thibang Martin','2008-05-17',FALSE),
('Keagan Dolly','2010-03-18',FALSE),
('Hildah Swart','2006-04-28',TRUE),
('Ongeziwe Mokwena','2007-04-21',FALSE),
('Lonathemba Dhlamini','2008-10-31',TRUE),
('Karabo Dlamini','2009-08-16',TRUE),
('Mosa Lebusa','2005-06-08',FALSE),
('Ruzaigh Zwane','2010-10-22',FALSE),
('Rivaldo Coetzee','2009-07-08',TRUE),
('Xiluva Jordaan','2010-09-08',TRUE),
('Sibulele Mhlongo','2009-02-27',FALSE),
('Luther Singh','2010-04-30',FALSE),
('Karabo Magaia','2006-08-09',TRUE),
('Bradley Grobler','2010-04-12',FALSE);


INSERT INTO tblRuimteskepe (Model, Spoed, BrandstofVerbruik, BrandstofKapasiteit) VALUES
('T941',5.49,656,8659),
('M793',3.03,314,4540),
('M327',3.3,970,3321),
('S766',4.29,811,5070),
('T666',3.97,129,8016),
('S379',3.96,956,1933),
('T766',1.48,894,4565),
('T494',2.87,708,7654),
('M366',2.42,639,2174),
('S336',5.58,274,7064),
('T419',4.6,610,9273),
('S390',5.23,115,5820),
('T288',2.51,466,6922),
('M641',3.74,542,8515),
('S178',4.16,943,3183),
('M256',2.87,446,5131),
('M880',2.23,887,5854),
('S174',4.21,776,9588),
('T204',2.81,300,2421),
('M763',1.71,362,6337),
('T367',2.33,457,6732),
('T257',2.05,239,6948),
('T313',1.32,282,4188),
('M313',5.34,768,3350),
('T382',1.56,226,7807),
('M845',4.29,845,4617),
('S529',1.5,326,7141),
('S897',5.17,454,7460),
('S406',1.5,486,9248),
('S956',2.02,124,9860);

INSERT INTO tblSendings (KapteinID, RuimteskipID, Hoofdoelwit, VertrekDatum, Afstand, Sonnestelsel) VALUES
(8,28,'Military Exercise','2024-04-19',6,'X-645G'),
(18,4,'Mining','2021-11-07',3,'F-331B'),
(30,18,'Military Exercise','2022-07-26',4,'U-184A'),
(16,8,'Military Exercise','2024-04-20',9,'F-306E'),
(20,16,'Mining','2025-05-01',7,'F-479C'),
(23,27,'Exploration','2025-12-10',10,'H-178D'),
(19,2,'Exploration','2025-12-12',2,'Q-987C'),
(15,3,'Exploration','2021-09-20',7,'E-615B'),
(33,23,'Military Exercise','2026-10-01',1,'I-179G'),
(2,5,'Rescue','2024-10-13',13,'W-695B'),
(37,13,'Scientific','2023-01-25',12,'W-441F'),
(14,6,'Exploration','2021-10-28',4,'U-965C'),
(26,29,'Scientific','2023-07-06',1,'K-978D'),
(45,14,'Military Exercise','2021-05-15',15,'X-642G'),
(34,24,'Scientific','2024-10-27',4,'C-273E'),
(44,11,'Military Exercise','2024-03-21',3,'H-937B'),
(9,1,'Military Exercise','2025-10-24',3,'V-594E'),
(46,10,'Scientific','2024-07-29',1,'L-809E'),
(5,17,'Scientific','2023-08-17',12,'U-734E'),
(13,19,'Scientific','2024-11-06',11,'J-565A'),
(43,7,'Scientific','2021-09-27',13,'B-411E'),
(35,12,'Scientific','2022-12-11',1,'O-492B'),
(29,22,'Military Exercise','2022-03-27',15,'Z-125D'),
(42,15,'Military Exercise','2023-11-17',14,'T-978G'),
(41,30,'Exploration','2022-06-01',8,'W-311C'),
(39,21,'Military Exercise','2023-02-04',8,'X-546B'),
(4,20,'Military Exercise','2022-07-25',9,'V-254B'),
(32,25,'Mining','2022-06-20',2,'S-246F'),
(7,9,'Scientific','2021-05-24',3,'W-589D'),
(40,26,'Exploration','2024-10-25',13,'Z-783G');