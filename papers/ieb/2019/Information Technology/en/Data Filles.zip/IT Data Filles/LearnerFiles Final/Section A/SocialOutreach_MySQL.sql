SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS STUDENT (
  StudentID int(11) NOT NULL,
  StudentName varchar(50) NOT NULL,
  IsSenior boolean NOT NULL,
  PRIMARY KEY (StudentID)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


INSERT INTO STUDENT (StudentID, StudentName, IsSenior) VALUES
(1, 'Jacob Ncube', TRUE),
(2, 'Samantha Marais', FALSE),
(3, 'Karabo Mlangeni', TRUE),
(4, 'Thapelo Mabena', FALSE),
(5, 'Nic de Klerk', FALSE),
(6, 'Kristen Naidoo', FALSE),
(7, 'Thabo Khoza', FALSE),
(8, 'Steven Govender', TRUE),
(9, 'Patricia Davids', TRUE),
(10, 'Ace Ngobese', FALSE),
(11, 'Michael Stemmet', TRUE),
(12, 'Kenneth Motala', TRUE),
(13, 'Mary-anne Muir', FALSE),
(14, 'Patience Madonsela', FALSE),
(15, 'Heinriche Pretorius', FALSE),
(16, 'Penny Mbele', TRUE),
(17, 'Kobus Venter', TRUE),
(18, 'Wiseman Legodi', TRUE),
(19, 'Caitlin Ruth', FALSE),
(20, 'Rethabile Mokone', TRUE),
(21, 'Bhule Mbasa', FALSE),
(22, 'Julia Hudson', TRUE),
(23, 'Luke Morkel', FALSE),
(24, 'Lungelo Nkosi', FALSE),
(25, 'Joshua Jacobs', TRUE),
(26, 'Gemma Fakier', FALSE),
(27, 'Somizi Baloyi', TRUE),
(28, 'Mpu Molefe', FALSE),
(29, 'Nikita van Wyk', FALSE),
(30, 'Andrea Badenhorst', TRUE),
(31, 'Mahmood Chetty', FALSE),
(32, 'Khensani Nguni', FALSE),
(33, 'Vicki de Beer', TRUE),
(34, 'Khaya Mokoena', FALSE),
(35, 'Conrad Snyman', FALSE),
(36, 'Zara Ndlovu', FALSE),
(37, 'Laetitia Adams', TRUE),
(38, 'Lesego Semenya', TRUE),
(39, 'Nina Ntsimango', TRUE),
(40, 'Dee Rajkoomar', FALSE),
(41, 'Wian Oosthuizen', TRUE),
(42, 'Frans Theron', FALSE),
(43, 'Mthokozisi Kumalo', TRUE),
(44, 'Prince Dube', TRUE),
(45, 'Ashley Louw', FALSE),
(46, 'Sego Dlamini', TRUE),
(47, 'Kendal Buys', TRUE),
(48, 'Mishka Hassen', FALSE),
(49, 'Mikyle Sithole', TRUE),
(50, 'Xavier Smith', FALSE),
(51, 'Tasneem Morkel', TRUE),
(52, 'Mia Gumede', FALSE),
(53, 'Amy Radebe', TRUE),
(54, 'Brendan Smit', TRUE),
(55, 'Blessing Mkhize', FALSE);


CREATE TABLE IF NOT EXISTS PROJECT (
  ProjectID int(11) NOT NULL,
  ProjectName varchar(80) NOT NULL,
  StudentLeaderID int(11) NOT NULL,
  DateStarted date NOT NULL,
  PRIMARY KEY (ProjectID)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


INSERT INTO PROJECT (ProjectID, ProjectName, StudentLeaderID, DateStarted) VALUES
(1, 'THU Sandwich feeding scheme', 1,'2019-1-17'),
(2, 'SAT English tutoring programme', 3,'2019-1-19'),
(3, 'SAT River clean up', 16,'2019-2-2'),
(4, 'FRI Mathematics tutorials', 12,'2019-1-18'),
(5, 'TUE Knitting for moms', 9,'2019-3-21'),
(6, 'MON Old Age Home Visit', 8,'2019-2-11'),
(7, 'WED Recycling Programme', 18,'2019-1-16'),
(8, 'FRI Textbook Collection', 25,'2019-3-21');


CREATE TABLE IF NOT EXISTS REGISTRATION (
  RegistrationID int(11) NOT NULL,
  StudentID integer NOT NULL,
  ProjectID integer NOT NULL,
  NumAttended integer NOT NULL,
  AccumulatedHours double NOT NULL ,
  PRIMARY KEY (RegistrationID)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO REGISTRATION (RegistrationID, StudentID, ProjectID, NumAttended, AccumulatedHours) VALUES
(1, 2, 1, 15, 16.25),
(2, 22, 1, 14, 12.5),
(3, 35, 1, 15, 12),
(4, 30, 2, 14, 11),
(5, 1, 2, 16, 13.5),
(6, 4, 1, 16, 17.5),
(7, 40, 1, 12, 8.5),
(8, 23, 2, 13, 11.75),
(9, 5, 1, 10, 9.25),
(10, 26, 3, 12, 11.5),
(11, 12, 1, 11, 10.25),
(12, 29, 4, 15, 16),
(13, 6, 4, 12, 13.5),
(14, 15, 1, 8, 6.5),
(15, 16, 5, 10, 10),
(16, 24, 5, 10, 10),
(17, 7, 2, 12, 10.5),
(18, 37, 7, 20, 10),
(19, 41, 2, 12, 10),
(20, 42, 3, 12, 13.5),
(21, 10, 2, 13, 11.5),
(22, 36, 6, 4, 6),
(23, 17, 8, 11, 10.25),
(24, 27, 6, 4, 6),
(25, 11, 3, 11, 10),
(26, 50, 7, 18, 9),
(27, 25, 2, 11, 9.5),
(28, 33, 5, 9, 9),
(29, 13, 7, 19, 9.5),
(30, 37, 6, 4, 6),
(31, 49, 7, 12, 6),
(32, 51, 3, 8, 6),
(33, 14, 4, 10, 8),
(34, 11, 8, 10, 9.5),
(35, 28, 7, 8, 4),
(36, 47, 6, 4, 6),
(37, 15, 4, 10, 8),
(38, 52, 6, 3, 4.5),
(39, 46, 8, 9, 9.5),
(40, 46, 3, 5, 3.5),
(41, 38, 5, 8, 8),
(42, 13, 6, 3, 4.5),
(43, 55, 4, 10, 8),
(44, 31, 8, 9, 8.5),
(45, 29, 3, 2, 1.5),
(46, 45, 5, 8, 8),
(47, 9, 7, 11, 5.5),
(48, 17, 5, 8, 8),
(49, 31, 1, 5, 3),
(50, 53, 5, 8, 8),
(51, 39, 6, 2, 3),
(52, 14, 7, 17, 8.5),
(53, 32, 8, 9, 7.5),
(54, 8, 7, 14, 7),
(55, 35, 6, 2, 3),
(56, 44, 2, 5, 6),
(57, 3, 4, 9, 8.5),
(58, 49, 3, 5, 4.5),
(59, 19, 8, 8, 7),
(60, 21, 2, 4, 3.5),
(61, 54, 4, 9, 8.25),
(62, 39, 8, 8, 6.5),
(63, 20, 3, 4, 3.75),
(64, 43, 4, 8, 7.75),
(65, 43, 6, 2, 3),
(66, 31, 7, 6, 3),
(67, 21, 4, 7, 6.5),
(68, 51, 4, 7, 6.5),
(69, 55, 5, 5, 5),
(70, 18, 8, 8, 6.5),
(71, 33, 7, 12, 6),
(72, 25, 7, 11, 5.5),
(73, 42, 6, 1, 1.5);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
