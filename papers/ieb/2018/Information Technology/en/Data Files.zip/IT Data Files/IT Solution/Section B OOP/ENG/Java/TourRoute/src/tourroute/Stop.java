// ENGLISH - Java
// Question 2
// Please see marking guideline for mark breakdown

package tourroute;

// Q2.1 - 1 Mark  
public class Stop {

    // Q2.2 - 3 Marks
    private String stopName;
    private String routeCodes;
    private int stopType;
    
    // Q2.3 - 3 Marks
    public static final int STOPTYPE_CAFE = 1;
    public static final int STOPTYPE_SHELTER = 2;
    public static final int STOPTYPE_EXPRESS = 3;
    public static final int STOPTYPE_OTHER = 4;
    
    
    // Q2.4 - 7 Marks 
    public Stop(String inStopName, String inRouteCodes, int inStopType)
    {
        stopName = inStopName;
        routeCodes = inRouteCodes;
        
        if (inStopType == STOPTYPE_CAFE || 
            inStopType == STOPTYPE_SHELTER || 
            inStopType == STOPTYPE_EXPRESS)
        {
            stopType = inStopType;
        }
        else
        {
            stopType = STOPTYPE_OTHER;
        }                
    }
 
    
    // Q2.5 - 3 Marks
    public String getStopTypeName()
    {
        switch (stopType)
        {
            case STOPTYPE_CAFE:
                return "cafe";
            case STOPTYPE_SHELTER:
                return "shelter";
            case STOPTYPE_EXPRESS:
                return "express";
            default:  
                return "other";
        }
    }
    
    
    // Q2.6 - 3 Marks
    public boolean isPartOfRoute(char r)
    {
        return (routeCodes.contains("" + r));
        
        // alternatives
        // use if statement to work out what to return
        /*
        if (routesCode.contains("" + r))
        {
            return true;
        }
        else
        {
            return false;
        }
        */
        // use indexOf
        //return (routeCodes.indexOf(r) > 0);
        
    }
    
    
    // Q2.7 - 3 Marks
    public String toString() {
        return  getStopTypeName() + "\t" + stopName;
    }
      
}
