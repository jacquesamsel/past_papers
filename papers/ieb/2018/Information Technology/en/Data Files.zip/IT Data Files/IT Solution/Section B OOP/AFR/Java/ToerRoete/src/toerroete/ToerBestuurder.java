// AFRIKAANS - Java
// Questions 4 and 7
// Please see marking guideline for mark breakdown

package toerroete;

import java.io.*;

// V4.1 – (1)
public class ToerBestuurder {
    
    // V4.2 – (3) 
    private Stop[] alleStoppe = new Stop[100];
    private int stopCount = 0;
    
   
    // V4.3 – (9) 
    public ToerBestuurder (String fn) 
    {
        try 
  {
            BufferedReader br = new BufferedReader(new FileReader(fn));
       
            
            String line = br.readLine();            

            while (line != null)
            {                
                String[] tokens = line.split(",");
                String sNaam = tokens[0];
                int sTipe = Integer.parseInt(tokens[1]);
                String rKodes = tokens[2];
                
                alleStoppe[stopCount] = new Stop(sNaam, rKodes, sTipe);
                // 1 L1 inkrementeer teller
                stopCount++;
                
                line = br.readLine();
                
            }
        } catch (Exception ex) { // of gee uitsondering
            System.out.println("Lêer nie gevind nie");
        }
    }
    

  
    // V4.4 – (10)
    public Roete kryRoeteMetKode(char inKode, boolean inIsSirkel)
    {
        Roete r = new Roete(inKode, inIsSirkel);
        
        
       

  



   
  

  



  // Alternatief 1: Skep presiese skikking en laai

  int count = 0;
        for (int i = 0; i < stopCount; i++) {
            if (alleStoppe[i].isDeelVanRoete(inKode))
            {
                count++;
            }
        }

        Stop[] arr = new Stop[count];
               
        count = 0;
        
        for (int i = 0; i < stopCount; i++) {
            if (alleStoppe[i].isDeelVanRoete(inKode))
            {
                arr[count] = alleStoppe[i]; 
                count++;
            }
        }
        // Einde van Alternatief 1
  

  // Alternatief 2: Skep dieselfde grootte as
  // alleStoppe – kopieer oor en verkort skikking
  /*
      Stop[] tempArr = new Stop[alleStoppe.length]; 
	  int count = 0;
        for (int i = 0; i < stopCount; i++) {
            if (alleStoppe[i].isDeelVanRoete(inKode))
            {
                tempArr[count] = alleStoppe[i]; 
		    count++;
            }
        }

	  Stop[] arr = new Stop[count];
	  System.arraycopy(tempArr, 0, arr, 0, count);
	  // of gebruik for-lus om na werklike skikking te kopieer

	  // Einde van Alternatief 2

*/
     	  r.stelStoppe(arr);
        
        return r;
        
    }
    
// V7.1 - (6) 
    public String werkStopPunteUit(Roete r1, Roete r2)
    {
       
        
      // Punte toegeken volgens doelwitte bereik:
       // 1 – O1: lus om deur roete 1-stoppe te gaan
       // 1 – O2: toets of dit ook aan roete 2 behoort
       // 1 – O3: doeltreffendheid – geen herlees van lêer, geen ander metode geskep nie
       // 1 – O4: stringaaneenskakeling korrek gedoen
       // 1 – O5: korrekte terugsending (0 indien daar terugsending is maar nie korrek nie)

      String toret = "";

      // alternatief 1: werk met die twee roetes
        
      int count = 0;
      Stop s = r1.kryStopBy(count);
      // s nie nodig nie – kan direk met r1.kryStopBy(count) werk;
        
      while (s != null)
      {
         if (s.isDeelVanRoete(r2.kryRoeteKode()))
         {
            toret += s + "\n";
         }
         count++;
         s = r1.kryStopBy(count);
      }
        
      return toret;

      // alternatief 2: werk met die alleStoppe-skikking
      /*
      for (int i = 0; i < stopCount; i++) 
      {
         if (alleStoppe[i].isDeelVanRoete(r1.kryRoeteKode()) 
             &&          
             alleStoppe[i].isDeelVanRoete(r2.kryRoeteKode()))
         {
             toret += alleStoppe[i] + "\n";
         }
      }
        
        return toret;
        */
   }

}



