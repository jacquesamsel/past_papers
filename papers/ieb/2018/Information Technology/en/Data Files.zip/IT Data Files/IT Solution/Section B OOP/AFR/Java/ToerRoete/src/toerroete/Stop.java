// AFRIKAANS - Java
// Question 2
// Please see marking guideline for mark breakdown


package toerroete;

// V2.1 - (1)
public class Stop {

    // V2.2 - (3)
    private String stopNaam;		
    private String roeteKodes; 
    private int stopTipe; 
    
    // V2.3 - (3) 
    public static final int STOPTIPE_KAFEE = 1;
    public static final int STOPTIPE_SKUILING = 2;
    public static final int STOPTIPE_SNEL = 3;
    public static final int STOPTIPE_ANDER = 4;

    // V2.4 – (7) 
    public Stop(String inStopNaam, String inRoeteKodes, int inStopTipe)
    {
        stopNaam = inStopNaam;
        roeteKodes = inRoeteKodes; 
        
        if (inStopTipe == STOPTIPE_KAFEE || 
            inStopTipe == STOPTIPE_SKUILING || 
            inStopTipe == STOPTIPE_SNEL)
        {
            stopTipe = inStopTipe;
		// aanvaar ook indien elkeen individueel gestel word
        }
        else
        {
            stopTipe = STOPTIPE_ANDER;
        }        
    }
    
    // V2.5 – (3)
    public String kryStopTipeNaam()
    {
        switch (stopTipe)          // if/else if/else aanvaarbaar
        {
            case STOPTIPE_KAFEE:
                return "kafee";
            case STOPTIPE_SNEL:
                return "snel";
            case STOPTIPE_SKUILING:
                return "skuiling";
            default:
                return "ander";
        }   
    }



 // V2.6 – (3)
    public boolean isDeelVanRoete(char r)
    {
        return (roeteKodes.contains("" + r));
        
        // alternatiewe
        // gebruik if-stelling om uit te werk wat om terug te stuur
        /*
        if (roeteKodes.contains("" + r))
        {
            return true;
        }
        else
        {
            return false;
        }


        // gebruik indexOf 
        return (roeteKodes.indexOf(r) > 0);

	  // gebruik indexOf met if
	  if (roeteKodes.indexOf(r) > 0)
        {
           return true;
        }
        else
        {
           return false;
        }
        */
    }
    

    // V2.7 – (3)
    public String toString() 
    {
        return kryStopTipeNaam() + "\t" + stopNaam;
    }
      
}

