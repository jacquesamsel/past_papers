// ENGLISH - Java
// Questions 3 and 5
// Please see marking guideline for mark breakdown

package tourroute;

// Q3.1 - 3 Marks
public class Route {
    private char routeCode;
    private boolean isCircular;
    private Stop[] stops;
    

    // Q3.2 - 2 Marks
    public Route(char inRouteCode, boolean inIsCircular)
    {
        routeCode = inRouteCode;
        isCircular = inIsCircular;
    }
    

    // Q3.3 - 2 Marks 
    public void setStops(Stop[] inStops)
    {
        stops = inStops;
    }

    
    // Q3.4 - 1 Mark 
    public char getRouteCode()
    {
        return routeCode;
    }
    
    
    // Q3.5 - 5 Marks 
    public Stop getStopAt(int num)
    {
        if (num >= 0 && num < stops.length)
        {
            return stops[num]; // or return "" + stops[num];
        }
        else return null; 
        
        // also accept if starting from 1
        // but Q7.1 should also match
        /*
        if (num >=1  && num <= stops.length)
        {
            return stops[num-1].toString();
        }
        else return ""; 
        */
        
    }


    
    // Q5 - 9 Marks
    public String toString()
    {
       String toRet = routeCode + " - ";
        
       if (stops.length == 0)   // also accept <= 0
       {
           toRet += "Invalid";
       }
       else
       {
            if (isCircular)
            {
                toRet += "Circular";
            }
            else
            {
                toRet += "Linear";
            }

            for (int i = 0; i < stops.length; i++) {
                toRet += "\n-> " + (i+1) + "\t" +  stops[i];
            } 


            if (isCircular)
            {
                toRet += "\n-> 1\t" + stops[0];
            }
            else
            {
                for (int i = stops.length -2 ; i >= 0; i--) {
                    toRet += "\n-> " + (i+1) + "\t" +  stops[i];
                }
            }
       }
       
       return toRet;    
    }
    
}
