// AFRIKAANS - Java
// Questions 3 and 5
// Please see marking guideline for mark breakdown

package toerroete;

// V3.1 – (3)
public class Roete {
    private char roeteKode;
    private boolean isSirkel;
    private Stop[] stoppe;
    
    // V3.2 – (2) 
    public Roete(char inRoeteKode, boolean inIsSirkel)
    {	
        roeteKode = inRoeteKode;
        isSirkel = inIsSirkel;
    }
    
    // V3.3 – (2)
    public void stelStoppe(Stop[] inStoppe) 
    {
        stoppe = inStoppe;
    }
    
    // V3.4 – (1)
    public char kryRoeteKode()
    {
        return roeteKode; 
    }
    
    // V3.5 – (5)
    public Stop kryStopBy(int num)
    {
        if (num >= 0 && num < stoppe.length)
        {
            return stoppe[num];
        }
        else return null;
        
         // aanvaar ook indien argument by 1 begin solank gleufverwerking
         //korrek is en V7.1 ook ooreenstem
        /*
        if (num >=1  && num <= stoppe.length)
        {
            return stoppe[num-1];
        }
        else return null; 
        */
        
    }
    
    
    // V5 – (9)
    public String toString()
    {
      String toRet = roeteKode + " - ";
        

      if (stoppe.length == 0)       // aanvaar ook <= 0
      {
          toRet += "Ongeldig";
      }
      else
      {

    
     if (isSirkel)
           {
              toRet += "Sirkel";
           }
           else
           {
              toRet += "Lineêr";
           }


           for (int i = 0; i < stoppe.length; i++) 
           {
              toRet += "\n-> " + (i+1) + "\t" + stoppe[i];
           } 





           if (isSirkel) 
           {
              toRet += "\n-> 1\t" + stoppe[0];
           }
           else
           {
              for (int i = stoppe.length -2 ; i >= 0; i--)
              {
                toRet += "\n-> " + (i+1) + "\t" + stoppe[i];
              }
           }
       }
       return toRet;    
    }
    
}



