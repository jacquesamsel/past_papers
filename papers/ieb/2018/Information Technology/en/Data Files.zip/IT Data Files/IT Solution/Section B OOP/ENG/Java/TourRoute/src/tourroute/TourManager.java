// ENGLISH - Java
// Questions 4 and 7
// Please see marking guideline for mark breakdown


package tourroute;

import java.io.*;

// Q4.1 - 1 Mark 
public class TourManager {
    
    // Q4.2 - 3 Marks 
    private Stop[] allStops = new Stop[100];
    private int stopCount = 0;
    
    
    // Q4.3 - 9 Marks
    public TourManager(String filename)
    {
        try {
            // Can also use Scanner to read file and split
            BufferedReader br = new BufferedReader(new FileReader(filename));
                   
            String line = br.readLine();
            
            while (line != null)
            {        
                String[] tokens = line.split(",");
                String tStopName = tokens[0];
                int tStopType = Integer.parseInt(tokens[1]);
                String tRouteCodes = tokens[2];
                
                allStops[stopCount] = new Stop(tStopName, tRouteCodes, tStopType);
                
                stopCount++;
                
                line = br.readLine();
                
            }
        } catch (Exception ex) { // or throws exception
            System.out.println("File not found");
        }
    }
    
    
    // Q4.4 - 10 Marks 
    public Route getRouteWithCode(char inCode, boolean inIsCircular)
    {
        Route r = new Route(inCode, inIsCircular);
        
        // Alternative 1: create exact array then load 
         /*
        int count = 0;
        for (int i = 0; i < stopCount; i++) {
            if (allStops[i].isPartOfRoute(inCode))
            {
                count++;
            }
        }

        Stop[] arr = new Stop[count];

        count = 0;
        
        for (int i = 0; i < stopCount; i++) {
            if (allStops[i].isPartOfRoute(inCode))
            {
                arr[count] = allStops[i];
                count++;
            }
        }
         */
        // End of Alternative 2
        
        // Alternative 2: Create same size array as
        // allStops – copy over and then shorten array
        // /*
		Stop[] tempArr = new Stop[allStops.length]; 
		int count = 0;
        for (int i = 0; i < stopCount; i++) {
            if (allStops[i].isPartOfRoute(inCode))
            {
                tempArr[count] = allStops[i]; 
		    count++;
            }
        }

		Stop[] arr = new Stop[count];
		System.arraycopy(tempArr, 0, arr, 0, count);
		// or use for loop to copy to actual array
        // */
		// End of Alternative 2
        
        r.setStops(arr);
        
        return r;
        
    }
    
    
    // Q7.1 - 6 Marks 
    public String workOutCommonStops(Route r1, Route r2)
    {
                
        String toret = "";
        
        // Alternative 1: working with the two routes
        /*
        int count = 0;
        Stop s = r1.getStopAt(count);  
        // s not necessary - can work directly with r1.getStopAt(count);
        
        while (s != null)
        {
            if (s.isPartOfRoute(r2.getRouteCode()))
            {
                toret += s + "\n";
            }
            count++;
            s = r1.getStopAt(count);
        }
        */
        // End of Alternative 1
        
        
        // alternative 2: Working with the allStops array
        // /*
        for (int i = 0; i < stopCount; i++) {
            if (allStops[i].isPartOfRoute(r1.getRouteCode()) && 
                allStops[i].isPartOfRoute(r2.getRouteCode()))
            {
                toret += allStops[i] + "\n";
            }
        }
        // */
        // End of Alternative 2
        
        return toret;
        
    }
            
}
