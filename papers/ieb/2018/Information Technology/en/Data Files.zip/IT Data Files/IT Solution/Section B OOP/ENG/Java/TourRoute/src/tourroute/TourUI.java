// ENGLISH - Java
// Question 6
// Please see marking guideline for mark breakdown


package tourroute;

public class TourUI {

    // 6.1 - 1 Mark
    public static void main(String[] args) {
        // 6.2 - 1 Mark
        TourManager sm = new TourManager("data.txt");
                
        // 6.3 - 2 Mark
        Route routeR = sm.getRouteWithCode('R', true);
        Route routeY = sm.getRouteWithCode('Y', false);

        // 6.4 - 1 mark - print both routes
        System.out.println(routeR);
        System.out.println(routeY);
        
        // 7.2 - 1 mark
        System.out.println(sm.workOutCommonStops(routeR, routeY));
        
    }
    
}
