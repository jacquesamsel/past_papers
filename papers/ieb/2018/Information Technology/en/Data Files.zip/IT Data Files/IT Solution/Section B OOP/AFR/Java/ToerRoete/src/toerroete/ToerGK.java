package toerroete;

// V6.1 - (1)
public class ToerGK {

    public static void main(String[] args) {
        
        // V6.2 - (1)
  ToerBestuurder sm = new ToerBestuurder("data.txt");

        
	  // V6.3 - (2)
        Roete roeteR = sm.kryRoeteMetKode('R', true);
        Roete roeteY = sm.kryRoeteMetKode('Y', false);
        

        // V6.4 (1) – druk albei roetes 
        System.out.println(roeteR);
	  System.out.println(roeteY);


	  // V7.2 - (1)
        System.out.println(sm.werkStopPunteUit(roeteR, roeteY));
        
    }
    
}

